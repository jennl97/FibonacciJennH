//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var a:Double = 0
var b:Double = 1

func fibonacci(_i: Double) -> Double{
    for _ in 1...999{
        print(a)
        let temp = a + b
        a = b
        b = temp
    }
    return b
}

print(fibonacci(1))
